var nomeSecreto = 3
var tentativas = 3

while (tentativas > 0) {

var chute= prompt("Digite 0 para Rihanna, digite 1 para Jorja, digite 2 para Willow, digite 3 para Robin:")

if (nomeSecreto ==chute) {
 document.write("<h2>"+ "Acertou" + "</h2>")
  break
 } else if (chute == 1) {
alert("Ela não é essa artista")
tentativas= tentativas-1 
} else if (chute > nomeSecreto) {
alert("Essa opção não existe")
tentativas= tentativas-1
} else if (chute == 0) { 
 alert("Esse é o nome artístico da cantora! Tente novamente.")
tentativas= tentativas-1
}  else if (chute == 2) { 
 alert("Ainda não!")
tentativas= tentativas-1
} 
}
if (chute != nomeSecreto) {
  document.write("<h2>"+"Suas tentativas acabaram. O nome da Rihanna é Robin Fenty."+"</h2>")
}