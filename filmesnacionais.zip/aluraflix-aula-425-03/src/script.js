var listaFilmes = ["http://br.web.img3.acsta.net/c_310_420/pictures/17/07/03/23/02/179143.jpg",
                   "https://media.fstatic.com/AUlDyMgYciCgQkSxA6NAsOHf5gw=/210x312/smart/media/movies/covers/2015/07/que-horas-ela-volta_t104058.jpg",
                   "https://media.fstatic.com/V0b5tznCQJUQwuF4gafIXxBPoNk=/210x312/smart/media/movies/covers/2014/02/hoje-eu-quero-voltar-sozinho_t44735_15.jpg", 
                   "https://media.fstatic.com/0s2AVPCusraWzUatnyQxTqgRTNM=/210x312/smart/media/movies/covers/2019/07/0636548.jpg-r_1920_1080-f_jpg-q_x-xxyxx.jpg",
                   "https://media.fstatic.com/0MEhSpAmwSqaQ8E5FaUsMk-gEO8=/210x312/smart/media/movies/covers/2019/06/afsgdh.jpg",
                   "https://media.fstatic.com/iDj8QCweOAn0Tecf0z2MYuJTBOQ=/210x312/smart/media/movies/covers/2020/08/funeste_kMMZrjp.jpg", 
                   "https://media.fstatic.com/sifzQEKqgB1k1DCmiy_Cy94tUkM=/210x312/smart/media/movies/covers/2009/03/acc8c9fc1091eeb6d4d9532cc95da6f6.jpg", 
                   "https://media.fstatic.com/D7HxPBatVSTYa-35ZkIxNg273l4=/210x312/smart/media/movies/covers/2012/02/3ba4915ccc5f21757df2c2b949b00dcd.jpg", "https://media.fstatic.com/nkmWRtAOY0DIQspqiZ55w5R1aJk=/290x478/smart/media/movies/covers/2012/02/b903c781b8c3b1919b227c88eb77d7ea.jpg", "https://media.fstatic.com/MR_cbaYqnW3j0TS_mvVXPGA1jlk=/210x312/smart/media/movies/covers/2012/10/1088db42d6b8ee2e1366863baf801de8.jpg", 
                   "https://media.fstatic.com/6A3tZSAof4hWhsNGs9NTfWia300=/210x312/smart/media/movies/covers/2011/06/b07a27de3c3b4730387879f7c80a6442.jpg", "https://media.fstatic.com/hjlXyO2Y_S03O01-K_WBSFkyvb0=/210x312/smart/media/movies/covers/2016/05/aquarius_t80043_yGfFPLM.jpg",
             "https://media.fstatic.com/p6fvLSZ2f3F8eeFNH_qN4JvJ1h4=/210x312/smart/media/movies/covers/2013/10/ultima-parada-174_t6369_1.jpg",
                   "https://media.fstatic.com/e41aoHjCSPo1UMc7asVguAuGG6s=/210x312/smart/media/movies/covers/2019/04/3836187.jpg", "https://media.fstatic.com/W5iPV3Tkk35wUrYfP-8iDeNCra4=/210x312/smart/media/movies/covers/2011/06/3894f6b2a5e1c6fa2a81c72a4b7cddb7.jpg",            "https://media.fstatic.com/VNgZVgClvNS2FQvjaanYE_-WNHw=/210x312/smart/media/movies/covers/2012/01/af7ee0981a7acd58d3617dd865b18a8f.jpg", "https://media.fstatic.com/VI8YOWkKrYhMjURASAiiUFpPTmk=/210x312/smart/media/movies/covers/2012/09/10495b57fdcc4cd1cc839e301813f0b5.jpg"]

for (var i = 0; i < listaFilmes.length; i ++) {
   document.write("<img src=" + listaFilmes[i] + ">")
//img scr para adicionar a imagem e não o código

}
 



// arrays  adiciona valores enquanto o código for rodando, seu indice começa com zero=primeiro elemento

//var filme1=
//var filme2=
//var filme3=

//console.log(filme1)
//console.log(filme2)
//console.log(filme3)

//var filmes = ["Star wars", "One day", "Django"] 

// quantidade de tentativas
//filmes.push("Star Wars")
//filmes.push("One day")

//var tentativas = 3
//while(tentativas > 0){
//quando as tentativas maior que 0 mostrar a função
//tentativas= tentativas - 1 }
//for (var i = 3; i <filmes.lengh; i++)//{
//i=tentativas
//i-- = i-1
//console.log (i)
//  console.log(filmes[i])}

//console.log(filmes[0])
//console.log(filmes.length)



