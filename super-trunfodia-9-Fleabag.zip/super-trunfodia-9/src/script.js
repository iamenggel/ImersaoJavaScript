var sister= {
  imagem: "https://mediaproxy.salon.com/width/1200/height/900/https://media.salon.com/2019/09/fleabag-still02.jpg",
nome: "Claire",
atributos: {
ataque:62,
defesa:96,
magia:60,
}
}
var stepMother= {
  imagem: "https://static.tvmaze.com/uploads/images/medium_portrait/184/462318.jpg",
nome: "Stepmother",
atributos: {
ataque:84,
defesa: 60,
magia: 92,
}
}
var thePriest= {
  imagem: "https://pyxis.nymag.com/v1/imgs/01c/f1d/7e469074dc71991136bee10305a3cb994d-13-fleabag-2.rsquare.w700.jpg",
nome: "The Priest",
atributos: {
ataque:64,
defesa: 82,
magia: 94,
}
}
var dad= {
  imagem: "https://static.tvmaze.com/uploads/images/medium_portrait/184/462315.jpg",
nome: "Dad",
atributos: {
ataque:52,
defesa: 84,
magia:78,
}
}
var deadFriend= {
  imagem: "https://static.tvmaze.com/uploads/images/medium_portrait/184/462316.jpg",
nome: "Boo",
atributos: {
ataque:60,
defesa:74,
magia:89,
}
}
var exBoyfriend= {
  imagem: "https://static.tvmaze.com/uploads/images/medium_portrait/184/462317.jpg",
nome: "Harry",
atributos: {
  ataque:62,
  defesa: 83,
  magia:61,
}
}
var bankManager= {
  imagem: "https://static.tvmaze.com/uploads/images/medium_portrait/184/462320.jpg",
nome: "Bank Manager",
atributos: {
ataque: 68,
defesa: 80,
magia: 82,
}
}
var brodherInLaw= {
  imagem: "https://static.tvmaze.com/uploads/images/medium_portrait/184/462314.jpg",
nome: "Martin",
atributos: {
ataque: 85,
defesa:60,
magia:70,
}
}
var Fleabag= {
  imagem: "https://static.tvmaze.com/uploads/images/medium_portrait/184/462312.jpg",
nome: "Fleabag",
atributos: {
ataque:80,
defesa: 82,
magia: 92,
}
}
var guineaPig= {
  imagem: "https://mrschristine.com/blog/images/2020/fleabag-guinea-pig.jpg",
nome: "Hilary",
atributos: {
ataque:52,
defesa: 60,
magia: 84,
}
}

var cartaMaquina
var cartaJogador
var cartas = [sister, stepMother, thePriest, dad, exBoyfriend, deadFriend, brodherInLaw, Fleabag, bankManager, guineaPig]
//            0           1           2          3         4            5            6           7     
var pontosJogador = 0
var pontosMaquina = 0

atualizaPlacar()
atualizaQuantidadeDeCartas()

function atualizaQuantidadeDeCartas() {
  var divQuantidadeCartas = document.getElementById('quantidade-cartas')
  var html = "Quantidade de cartas no jogo: " + cartas.length
  divQuantidadeCartas.innerHTML = html
}

function atualizaPlacar(){
  var divPlacar = document.getElementById('placar')
  var html = "Jogador"+ pontosJogador + "/" + pontosMaquina + "Máquina"
  
  divPlacar.inner = html
}
function sortearCarta() {
    var numeroCartaMaquina = parseInt(Math.random() * cartas.length)
    cartaMaquina = cartas[numeroCartaMaquina]
cartas.splice(numeroCartaMaquina, 1)
  
    var numeroCartaJogador = parseInt(Math.random() * cartas.length)
    //while (numeroCartaJogador == numeroCartaMaquina) {
        //numeroCartaJogador = parseInt(Math.random() * 3)
   // }
    cartaJogador = cartas[numeroCartaJogador]
    //console.log(cartaJogador)
  cartas.splice(numeroCartaJogador, 1)

    document.getElementById('btnSortear').disabled = true 
  document.getElementById('btnJogar').disabled = false

    exibeCartaJogador()
}


function exibeCartaJogador() {
    var divCartaJogador = document.getElementById("carta-jogador")
    var moldura = '<img src="https://www.alura.com.br/assets/img/imersoes/dev-2021/card-super-trunfo-transparent.png" style=" width: inherit; height: inherit; position: absolute;">';
    divCartaJogador.style.backgroundImage = `url(${cartaJogador.imagem})`
    var nome = `<p class="carta-subtitle">${cartaJogador.nome}</p>`
    var opcoesTexto = ""

    for (var atributo in cartaJogador.atributos) {
        opcoesTexto += "<input type='radio' name='atributo' value='" + atributo + "'>" + atributo + " " + cartaJogador.atributos[atributo] + "<br>"
    }

    var html = "<div id='opcoes' class='carta-status'>"

    divCartaJogador.innerHTML = moldura + nome + html + opcoesTexto + '</div>'
}

function obtemAtributoSelecionado() {
    var radioAtributo = document.getElementsByName('atributo')
    for (var i = 0; i < radioAtributo.length; i++) {
        if (radioAtributo[i].checked) {
            return radioAtributo[i].value
        }
    }
}

function jogar() {
    var divResultado = document.getElementById("resultado")
    var atributoSelecionado = obtemAtributoSelecionado()

    if (cartaJogador.atributos[atributoSelecionado] > cartaMaquina.atributos[atributoSelecionado]) {
        htmlResultado = '<p class="resultado-final">Venceu</p>'
      pontosJogador++
    } else if (cartaJogador.atributos[atributoSelecionado] < cartaMaquina.atributos[atributoSelecionado]) {
        htmlResultado = '<p class="resultado-final">Perdeu</p>'
      pontosMaquina++  
    } else {
        htmlResultado = '<p class="resultado-final">Empatou</p>'
    }
  
if(cartas.length==0){
  alert("Fim de jogo")
      if (pontosJogador > pontosMaquina){
        htmlResultado = '<p class="resultado-final">Venceu</p>'
      }  else if (pontosMaquina > pontosJodador){htmlResultado = '<p class="resultado-final">Perdeu</p>'
                } else {
         htmlResultado = '<p class="resultado-final">Empatou</p>'   
                }
} else { document.getElementById('btnProximaRodada').disabled = false
  }
    divResultado.innerHTML = htmlResultado
  document.getElementById('btnJogar').disabled= true
  document.getElementById('btnProximaRodada').disabled= false
  
  atualizaPlacar()
  exibeCartaMaquina()
}

function exibeCartaMaquina() {
    var divCartaMaquina = document.getElementById("carta-maquina")
    var moldura = '<img src="https://www.alura.com.br/assets/img/imersoes/dev-2021/card-super-trunfo-transparent.png" style=" width: inherit; height: inherit; position: absolute;">';
    divCartaMaquina.style.backgroundImage = `url(${cartaMaquina.imagem})`
    var nome = `<p class="carta-subtitle">${cartaMaquina.nome}</p>`
    var opcoesTexto = ""

    for (var atributo in cartaMaquina.atributos) {
        console.log(atributo)
        opcoesTexto += "<p type='text' name='atributo' value='" + atributo + "'>" + atributo + " " + cartaMaquina.atributos[atributo] + "<br>"
    }

    var html = "<div id='opcoes' class='carta-status --spacing'>"

    divCartaMaquina.innerHTML = moldura + nome + html + opcoesTexto + '</div>'
}

function proximaRodada() {
  var divCartas = document.getElementById('cartas')
  divCartas.innerHTML = '<div id="carta-jogador" clas="carta"></div> <div id="carta-maquina" class="carta"></div>'
  document.getElementById('btnSortear').disabled =false
   document.getElementById('btnJogar').disabled =true
   document.getElementById('btnProximaRodada').disabled =true
  
 var divResultado = document.getElementById('resultado')
 divResultado.innerHTML = ""
}