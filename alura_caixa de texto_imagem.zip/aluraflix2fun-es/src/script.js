//console.log("iniciou o programa")

function adicionarFilme() {
var campoFilmeFavorito = document.querySelector('#filme')
var filmeFavorito = campoFilmeFavorito.value
if (filmeFavorito.endsWith('.jpg')) {
listarFilmesNaTela(filmeFavorito)
} else {
alert("Imagem inválida")
}
campoFilmeFavorito.value = ""
}
function listarFilmesNaTela(filme) {
  var listaFilmes = document.querySelector('#listaFilmes')
  var elementoFilme = "<img src=" + filme + ">"
  listaFilmes.innerHTML = listaFilmes.innerHTML + elementoFilme
}

//.value só o nome do filme
//ducument.querySelector chama no html o que está entre parenteses #seleciona a id "filme" 
//console.log("clicou")
//console.log("terminou o programa")

//guardar a informação pra mostrar a imagem
//id filme HTML o input é a caixa para inserir a informação