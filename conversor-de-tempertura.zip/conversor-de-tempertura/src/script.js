var primeiroValor = parseFloat(prompt("Digite o valor em graus celsius (°C):"))

var operacao = prompt("Digite 1 para Fahrenheit ou digite 2 para Kelvin :") 

if (operacao == 1){
  var resultado = (primeiroValor * (9/5) + 32).toFixed(2)
  document.write("<h2>"+ primeiroValor + "°C" + "=" + resultado +  "°F" + "</h2>")
} else if(operacao == 2) {
  var resultado = (primeiroValor + 273.15).toFixed(2)
  document.write("<h2>"+ primeiroValor + "°C" + "=" + resultado + "K" + "</h2>")
}else {
  document.write("<h2>Opção inválida</h2>")
}